/**
 * Created by gusrod on 2017-02-23.
 */
public class Pair<A, B> {
    public A a;
    public B b;
    int score;

    public Pair(A a, B b) {
        this.a = a;
        this.b = b;
    }
}
